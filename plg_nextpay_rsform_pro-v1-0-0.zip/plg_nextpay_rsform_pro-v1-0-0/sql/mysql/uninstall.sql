DROP TABLE IF EXISTS `#__rsform_payment`;

DELETE FROM #__rsform_config WHERE SettingName = 'nextpay.api_key';

DELETE FROM #__rsform_component_types WHERE ComponentTypeId = 642;
DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 642;
