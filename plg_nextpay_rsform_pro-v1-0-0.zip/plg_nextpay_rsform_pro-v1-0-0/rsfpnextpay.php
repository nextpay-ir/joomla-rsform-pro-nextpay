<?php
/**
 * Nextpay Payment Gateway Plugin for RSForm!Pro Component
 * PHP version 5.6+
 * @author Nextpay <info@nextpay.ir>
 * @copyright 2016-2017 NextPay.ir
 * @version 1.0.0
 * @link http://www.nextpay.ir
 */

defined('_JEXEC') or die('Restricted access');

class plgSystemRSFPNextPay extends JPlugin
{
	protected $componentId = 642;
	protected $componentValue = 'nextpay';

	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->newComponents = array(642);
	}

	/*
	 * display Nextpay menu items
	 */
	public function rsfp_bk_onAfterShowComponents()
	{
		JFactory::getLanguage()->load('plg_system_rsfpnextpay');

		$formId = JFactory::getApplication()->input->getInt('formId');

		$link = "displayTemplate('" . $this->componentId . "')";
		if ($components = RSFormProHelper::componentExists($formId, $this->componentId))
			$link = "displayTemplate('" . $this->componentId . "', '" . $components[0] . "')";
		?>
		<li><a href="javascript: void(0);" onclick="<?php echo $link; ?>;return false;"
			   id="rsfpc<?php echo $this->componentId; ?>"><span class="rsficon rsficon-nextpay"></span><span
					class="inner-text"><?php echo JText::_('RSFP_NEXPAY_COMPONENT'); ?></span></a></li>
		<?php
	}

	/*
	 * get what type of payment is ex. paypal or nextpay
	 */
	public function rsfp_getPayment(&$items, $formId)
	{
		if ($components = RSFormProHelper::componentExists($formId, $this->componentId)) {
			$data = RSFormProHelper::getComponentProperties($components[0]);

			$item = new stdClass();
			$item->value = $this->componentValue;
			$item->text = $data['LABEL'];

			// add to array
			$items[] = $item;
		}
	}

	/*
	 * do payment:
	 * get config and redirect to nextpay
	 */
	public function rsfp_doPayment($payValue, $formId, $SubmissionId, $price, $products, $code)
	{
		$app = JFactory::getApplication();
		try {
			// execute only for our plugin
			if ($payValue != $this->componentValue)
				throw new Exception(JText::_('پلاکین مورد استفاده نکست پی نمی باشد'));
			if ($price <= 0)
				throw new Exception(JText::_('مبلغ نباید منفی یا صفر باشد'));

			$api_key = RSFormProHelper::getConfig('nextpay.api_key');
			if (empty($api_key))
				throw new Exception(JText::_('کد مجوزدهی را برای استفاده از درگاه در تنظیمات وارد نمایید'));

			$amount = $this->NextpayAmount($price);
			$order_id = time();
			
			if (empty($formId))
				$formId = $app->input->getInt('formId');

			$callback_uri = JURI::root() . 'index.php?option=com_rsform&formId=' . $formId . '&task=plugin&plugin_task=nextpay.notify&amount=' . $amount . '&code=' . $code;

			$params = compact(
				'api_key',
				'amount',
				'order_id',
				'callback_uri'
			);
			
			include_once "nextpay_payment.php";
			
			$nextpay = new Nextpay_Payment($params);

			$result = $nextpay->token();

			if(intval($result->code) == -1) {
			    //$nextpay->send($result->trans_id);
			    $app->redirect("http://api.nextpay.org/gateway/payment/{$result->trans_id}");
			} else {
			    throw new Exception('اشکالی در ارتباط با پرداخت با درگاه نکست پی پیش آمده است');
			}


			$app->enqueueMessage($nextpay->code_error($result->code), 'error');
			return false;

		} catch (Exception $e) {
			$app->enqueueMessage($e->getMessage(), 'error');
			return;
		}
	}

	/*
	 * detect currency for amount
	 */
	private function NextpayAmount($price)
	{
		$currency = RSFormProHelper::getConfig('payment.currency');
		switch ($currency)
		{
			case 'ریال':
			case 'IRR':
			case 'RIAL':
			case 'Rial':
			case 'rial':
				$price = (int)($price / 10);
				break;
			case 'تومان':
			case 'IRT':
			case 'TOMAN':
			case 'Toman':
			case 'toman':
			default:
				$price = (int)$price;
				break;
		}
		return $price;
	}

	/*
	 * this will set display of nextpay payment into form
	 */
	public function rsfp_bk_onAfterCreateComponentPreview($args = array())
	{
		if ($args['ComponentTypeName'] == 'nextpay') {
			$args['out'] = '<td>&nbsp;</td>';
			$args['out'] .= '<td><span style="font-size:24px;margin-right:5px" class="rsficon rsficon-nextpay"></span> ' . $args['data']['LABEL'] . '</td>';
		}
	}

	/*
	 * this will be done when configuration page displayed
	 * and call function 'NextPayConfigurationScreen'
	 */
	public function rsfp_bk_onAfterShowConfigurationTabs($tabs)
	{
		JFactory::getLanguage()->load('plg_system_rsfpnextpay');

		$tabs->addTitle(JText::_('RSFP_NEXTPAY_LABEL'), 'form-nextpay');
		$tabs->addContent($this->NextPayConfigurationScreen());
	}

	/*
	 * check to see what to do when back to site from nextpay
	 */
	public function rsfp_f_onSwitchTasks()
	{
		try {
			include_once "nextpay_payment.php";
			$app = JFactory::getApplication();
			$input = $app->input;
			$pluginTask = $input->getString('plugin_task', '');
			if ($pluginTask != 'nextpay.notify')
				throw new Exception(sprintf("وظیفه %s برای نکست پی تعریف نشده است", $pluginTask));

			$amount = $input->getInt('amount');
			$trans_id = $input->getString('trans_id');
			$order_id = $input->getString('order_id');
			$api_key = RSFormProHelper::getConfig('nextpay.api_key');

			$params = compact('trans_id', 'api_key', 'order_id', 'amount');
			$nextpay = new Nextpay_Payment();
			
			$verify = $nextpay->verify_request($params);

			$status = intval($verify);
			$root = JURI::root();
			$return = RSFormProHelper::getConfig('nextpay.return');
			$return = empty($return) ? $root : $return;
			$htmlStart = "<!DOCTYPE html><html><head><meta charset='utf-8' ></head><body>";
			$htmlEnd = "</body></html>";

			if ($status == 0) {
				$RefID = $trans_id;
				$db = JFactory::getDBO();
				$code = $input->getCmd('code');
				$formId = $input->getInt('formId');
				$db->setQuery("SELECT SubmissionId FROM #__rsform_submissions s WHERE s.FormId='" . $formId . "' AND MD5(CONCAT(s.SubmissionId,s.DateSubmitted)) = '" . $db->escape($code) . "'");
				if ($SubmissionId = $db->loadResult()) {
					$db->setQuery("UPDATE #__rsform_submission_values sv SET sv.FieldValue=1 WHERE sv.FieldName='_STATUS' AND sv.FormId='" . $formId . "' AND sv.SubmissionId = '" . $SubmissionId . "'");
					$db->execute();

					$app->triggerEvent('rsfp_afterConfirmPayment', array($SubmissionId));
				}
				$message = sprintf(
					"%s<p style='font:bold 16px tahoma; color:darkgreen; direction:rtl; text-align:center;'>پرداخت با موفقیت انجام شد<br>شماره پیگیری تراکنش:<br>%s<br><a href='%s'>برای ادامه کلیک کنید!</a></p>%s",
					$htmlStart,
					$RefID,
					$return,
					$htmlEnd
				);

				echo $message;
				jexit('');
			}

			$status = $nextpay->code_error($status);
			$message = sprintf(
				"%s<p style='font:bold 16px tahoma; color:darkred; direction:rtl; text-align:center;'>پرداخت ناموفق بود<br>خطای پیش آمده:<br>%s<br><a href='%s'>برای ادامه کلیک کنید!</a></p>%s",
				$htmlStart,
				$status,
				$root,
				$htmlEnd
			);

			echo $message;

		} catch (Exception $e) {
			echo $e->getMessage();
			exit;
		}
	}

	/*
	 * create nextpay configuration page
	 */
	private function NextPayConfigurationScreen()
	{
		ob_start();

		?>
		<div id="page-nextpay" class="com-rsform-css-fix">
			<table class="admintable">
				<tr>
					<td width="200" style="width: 200px;" align="right" class="key"><label
							for="api_key"><?php echo JText::_('RSFP_NEXTPAY_API_KEY'); ?></label></td>
					<td><input id="api_key" type="text" name="rsformConfig[nextpay.api_key]"
							   value="<?php echo RSFormProHelper::htmlEscape(RSFormProHelper::getConfig('nextpay.api_key')); ?>"
							   size="100" maxlength="64"></td>
				</tr>
                <tr>
                    <td width="200" style="width: 200px;" align="right" class="key"><label
                            for="return"><?php echo JText::_('RSFP_NEXTPAY_RETURN'); ?></label></td>
                    <td><input id="return" type="text" name="rsformConfig[nextpay.return]"
                               value="<?php echo RSFormProHelper::htmlEscape(RSFormProHelper::getConfig('nextpay.return')); ?>"
                               size="200" maxlength="500"></td>
                </tr>
            </table>
		</div>
		<?php

		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}
}
